package com.javacodegeeks.examples.wordcount;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 * Map Class which extends MaReduce.Mapper class Map is passed a single line at
 * a time, it splits the line based on space and generated the token which are
 * output by map with value as one to be consumed by reduce class
 * 
 * @author Raman
 */
public class MapClass extends Mapper<LongWritable, Text, IntWritable, FloatWritable> {

	/**
	 * map function of Mapper parent class takes a line of text at a time splits to
	 * tokens and passes to the context as word along with value as one
	 */
	@Override
	protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		try {

			String line = value.toString();
	        String[] words = line.split(",");
	        IntWritable outputKey = new IntWritable(Integer.parseInt(words[0]));
	        FloatWritable outputValue = new FloatWritable(Float.parseFloat(words[1]));
	        context.write(outputKey, outputValue);
		} catch (Exception e) {
			System.out.printf("Error: ", e);
		}

	}
}
